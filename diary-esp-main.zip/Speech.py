import speech_recognition as sr

def speech():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        r.adjust_for_ambient_noise(source)  
        print("Di algo!")
        audio = r.listen(source)

    try:
        return(r.recognize_google(audio, language="es-ES"))
    except sr.UnknownValueError:
        return("No se entiende lo que dijiste")
    except sr.RequestError as e:
        return("Error del servidor 404")

print(speech())
